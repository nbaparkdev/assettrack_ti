--
-- PostgreSQL database dump
--

\restrict QhvD2eGrad2IaxBamhzBZtFbpENclcldia5p8gikeYIYmNfYGIcXyd4x6HVporb

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: assetstatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.assetstatus AS ENUM (
    'DISPONIVEL',
    'EM_USO',
    'MANUTENCAO',
    'ARMAZENADO',
    'BAIXADO'
);


ALTER TYPE public.assetstatus OWNER TO "user";

--
-- Name: destinomanutencao; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.destinomanutencao AS ENUM (
    'ARMAZENAMENTO',
    'USUARIO'
);


ALTER TYPE public.destinomanutencao OWNER TO "user";

--
-- Name: maintenancecriticality; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.maintenancecriticality AS ENUM (
    'BAIXA',
    'MEDIA',
    'ALTA',
    'CRITICA'
);


ALTER TYPE public.maintenancecriticality OWNER TO "user";

--
-- Name: maintenanceperiodicity; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.maintenanceperiodicity AS ENUM (
    'DIARIA',
    'SEMANAL',
    'QUINZENAL',
    'MENSAL',
    'BIMESTRAL',
    'TRIMESTRAL',
    'SEMESTRAL',
    'ANUAL',
    'PERSONALIZADA'
);


ALTER TYPE public.maintenanceperiodicity OWNER TO "user";

--
-- Name: maintenancepriority; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.maintenancepriority AS ENUM (
    'BAIXA',
    'MEDIA',
    'ALTA',
    'URGENTE'
);


ALTER TYPE public.maintenancepriority OWNER TO "user";

--
-- Name: maintenancetype; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.maintenancetype AS ENUM (
    'PREVENTIVA',
    'PREDITIVA',
    'INSPECAO',
    'CALIBRACAO',
    'LUBRIFICACAO',
    'LIMPEZA',
    'ATUALIZACAO'
);


ALTER TYPE public.maintenancetype OWNER TO "user";

--
-- Name: orderstatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.orderstatus AS ENUM (
    'ABERTA',
    'AGENDADA',
    'EM_ANDAMENTO',
    'AGUARDANDO_PECA',
    'PAUSADA',
    'CONCLUIDA',
    'CANCELADA'
);


ALTER TYPE public.orderstatus OWNER TO "user";

--
-- Name: phototype; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.phototype AS ENUM (
    'ANTES',
    'DURANTE',
    'DEPOIS'
);


ALTER TYPE public.phototype OWNER TO "user";

--
-- Name: prioridadesolicitacao; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.prioridadesolicitacao AS ENUM (
    'BAIXA',
    'MEDIA',
    'ALTA',
    'CRITICA'
);


ALTER TYPE public.prioridadesolicitacao OWNER TO "user";

--
-- Name: producttype; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.producttype AS ENUM (
    'PRODUTO',
    'SERVICO',
    'LICENCA',
    'ASSINATURA',
    'EQUIPAMENTO',
    'MATERIAL_CONSUMO'
);


ALTER TYPE public.producttype OWNER TO "user";

--
-- Name: purchaseorderstatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.purchaseorderstatus AS ENUM (
    'ABERTO',
    'ENVIADO',
    'ACEITO',
    'EM_TRANSPORTE',
    'RECEBIDO_PARCIAL',
    'RECEBIDO_TOTAL',
    'CANCELADO'
);


ALTER TYPE public.purchaseorderstatus OWNER TO "user";

--
-- Name: purchaserequeststatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.purchaserequeststatus AS ENUM (
    'RASCUNHO',
    'PENDENTE',
    'EM_APROVACAO',
    'APROVADA',
    'REPROVADA',
    'CANCELADA',
    'CONVERTIDA_COTACAO',
    'AGUARDANDO_ORCAMENTO'
);


ALTER TYPE public.purchaserequeststatus OWNER TO "user";

--
-- Name: qrlogaction; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.qrlogaction AS ENUM (
    'LOGIN',
    'LOGIN_FAILED',
    'REGENERATE',
    'PIN_SET',
    'PIN_CHANGED',
    'PROFILE_VIEW',
    'DELIVERY_CONFIRM'
);


ALTER TYPE public.qrlogaction OWNER TO "user";

--
-- Name: statusmanutencao; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.statusmanutencao AS ENUM (
    'EM_ANDAMENTO',
    'CONCLUIDA',
    'CANCELADA'
);


ALTER TYPE public.statusmanutencao OWNER TO "user";

--
-- Name: statussolicitacao; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.statussolicitacao AS ENUM (
    'PENDENTE',
    'APROVADA',
    'ENTREGUE',
    'REJEITADA',
    'CANCELADA'
);


ALTER TYPE public.statussolicitacao OWNER TO "user";

--
-- Name: statussolicitacaomanutencao; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.statussolicitacaomanutencao AS ENUM (
    'PENDENTE',
    'ACEITA',
    'EM_ANDAMENTO',
    'AGUARDANDO_ENTREGA',
    'ENTREGUE',
    'CONCLUIDA',
    'REJEITADA'
);


ALTER TYPE public.statussolicitacaomanutencao OWNER TO "user";

--
-- Name: tipomanutencao; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.tipomanutencao AS ENUM (
    'PREVENTIVA',
    'CORRETIVA',
    'UPGRADE',
    'OUTRO'
);


ALTER TYPE public.tipomanutencao OWNER TO "user";

--
-- Name: tipomovimentacao; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.tipomovimentacao AS ENUM (
    'EMPRESTIMO',
    'DEVOLUCAO',
    'TRANSFERENCIA',
    'MANUTENCAO',
    'BAIXA',
    'CADASTRO'
);


ALTER TYPE public.tipomovimentacao OWNER TO "user";

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'GERENTE',
    'TECNICO',
    'GERENTE_INFRA',
    'COMPRADOR',
    'USUARIO',
    'comprador'
);


ALTER TYPE public.userrole OWNER TO "user";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: armazenamentos; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.armazenamentos (
    id integer NOT NULL,
    nome character varying NOT NULL,
    capacidade_max integer NOT NULL,
    tipo_itens character varying
);


ALTER TABLE public.armazenamentos OWNER TO "user";

--
-- Name: armazenamentos_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.armazenamentos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.armazenamentos_id_seq OWNER TO "user";

--
-- Name: armazenamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.armazenamentos_id_seq OWNED BY public.armazenamentos.id;


--
-- Name: asset_categories; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.asset_categories (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text
);


ALTER TABLE public.asset_categories OWNER TO "user";

--
-- Name: asset_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.asset_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_categories_id_seq OWNER TO "user";

--
-- Name: asset_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.asset_categories_id_seq OWNED BY public.asset_categories.id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    nome character varying NOT NULL,
    e_patrimonio character varying NOT NULL,
    modelo character varying,
    descricao character varying,
    data_aquisicao timestamp without time zone,
    valor numeric(10,2),
    status public.assetstatus NOT NULL,
    qr_code_path character varying,
    foto_path character varying,
    numero_serie character varying,
    em_posse_de character varying,
    bloqueado boolean NOT NULL,
    categoria_id integer,
    created_by_id integer,
    fornecedor_id integer,
    nota_fiscal_id integer,
    current_user_id integer,
    current_departamento_id integer,
    current_local_id integer,
    current_armazenamento_id integer
);


ALTER TABLE public.assets OWNER TO "user";

--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assets_id_seq OWNER TO "user";

--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.assets_id_seq OWNED BY public.assets.id;


--
-- Name: cost_centers; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.cost_centers (
    id integer NOT NULL,
    codigo character varying(50) NOT NULL,
    nome character varying(100) NOT NULL,
    departamento_id integer,
    responsavel_id integer,
    orcamento_anual numeric(12,2) NOT NULL,
    orcamento_mensal numeric(12,2) NOT NULL,
    orcamento_anual_usado numeric(12,2) NOT NULL,
    orcamento_mensal_usado numeric(12,2) NOT NULL,
    alerta_limite boolean NOT NULL,
    bloquear_limite boolean NOT NULL
);


ALTER TABLE public.cost_centers OWNER TO "user";

--
-- Name: cost_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.cost_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cost_centers_id_seq OWNER TO "user";

--
-- Name: cost_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.cost_centers_id_seq OWNED BY public.cost_centers.id;


--
-- Name: departamentos; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.departamentos (
    id integer NOT NULL,
    nome character varying NOT NULL,
    responsavel_id integer
);


ALTER TABLE public.departamentos OWNER TO "user";

--
-- Name: departamentos_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.departamentos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departamentos_id_seq OWNER TO "user";

--
-- Name: departamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.departamentos_id_seq OWNED BY public.departamentos.id;


--
-- Name: fornecedores; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.fornecedores (
    id integer NOT NULL,
    nome character varying NOT NULL,
    razao_social character varying,
    cnpj character varying,
    email character varying,
    telefone character varying,
    endereco character varying,
    cidade character varying,
    estado character varying,
    tipo_fornecedor character varying
);


ALTER TABLE public.fornecedores OWNER TO "user";

--
-- Name: fornecedores_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.fornecedores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fornecedores_id_seq OWNER TO "user";

--
-- Name: fornecedores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.fornecedores_id_seq OWNED BY public.fornecedores.id;


--
-- Name: locais; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.locais (
    id integer NOT NULL,
    nome character varying NOT NULL,
    departamento_id integer
);


ALTER TABLE public.locais OWNER TO "user";

--
-- Name: locais_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.locais_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locais_id_seq OWNER TO "user";

--
-- Name: locais_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.locais_id_seq OWNED BY public.locais.id;


--
-- Name: maintenance_checklist_items; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_checklist_items (
    id integer NOT NULL,
    checklist_id integer NOT NULL,
    descricao text NOT NULL,
    obrigatorio boolean NOT NULL,
    ordem integer NOT NULL,
    requer_foto boolean NOT NULL
);


ALTER TABLE public.maintenance_checklist_items OWNER TO "user";

--
-- Name: maintenance_checklist_items_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_checklist_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_checklist_items_id_seq OWNER TO "user";

--
-- Name: maintenance_checklist_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_checklist_items_id_seq OWNED BY public.maintenance_checklist_items.id;


--
-- Name: maintenance_checklists; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_checklists (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    nome character varying(200) NOT NULL,
    ordem integer NOT NULL
);


ALTER TABLE public.maintenance_checklists OWNER TO "user";

--
-- Name: maintenance_checklists_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_checklists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_checklists_id_seq OWNER TO "user";

--
-- Name: maintenance_checklists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_checklists_id_seq OWNED BY public.maintenance_checklists.id;


--
-- Name: maintenance_executions; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_executions (
    id integer NOT NULL,
    order_id integer NOT NULL,
    checklist_item_id integer NOT NULL,
    concluido boolean NOT NULL,
    observacao text,
    data_execucao timestamp without time zone,
    executado_por_id integer
);


ALTER TABLE public.maintenance_executions OWNER TO "user";

--
-- Name: maintenance_executions_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_executions_id_seq OWNER TO "user";

--
-- Name: maintenance_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_executions_id_seq OWNED BY public.maintenance_executions.id;


--
-- Name: maintenance_history; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_history (
    id integer NOT NULL,
    order_id integer NOT NULL,
    acao character varying(100) NOT NULL,
    descricao text NOT NULL,
    usuario_id integer,
    data_hora timestamp without time zone NOT NULL,
    status_anterior character varying(50),
    status_novo character varying(50)
);


ALTER TABLE public.maintenance_history OWNER TO "user";

--
-- Name: maintenance_history_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_history_id_seq OWNER TO "user";

--
-- Name: maintenance_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_history_id_seq OWNED BY public.maintenance_history.id;


--
-- Name: maintenance_materials; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_materials (
    id integer NOT NULL,
    order_id integer NOT NULL,
    produto character varying(200) NOT NULL,
    quantidade numeric(10,2) NOT NULL,
    valor_unitario numeric(10,2) NOT NULL,
    valor_total numeric(10,2) NOT NULL,
    observacao text
);


ALTER TABLE public.maintenance_materials OWNER TO "user";

--
-- Name: maintenance_materials_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_materials_id_seq OWNER TO "user";

--
-- Name: maintenance_materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_materials_id_seq OWNED BY public.maintenance_materials.id;


--
-- Name: maintenance_notifications; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_notifications (
    id integer NOT NULL,
    order_id integer,
    plan_id integer,
    usuario_id integer NOT NULL,
    tipo character varying(50) NOT NULL,
    mensagem text NOT NULL,
    lida boolean NOT NULL,
    data_criacao timestamp without time zone NOT NULL
);


ALTER TABLE public.maintenance_notifications OWNER TO "user";

--
-- Name: maintenance_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_notifications_id_seq OWNER TO "user";

--
-- Name: maintenance_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_notifications_id_seq OWNED BY public.maintenance_notifications.id;


--
-- Name: maintenance_orders; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_orders (
    id integer NOT NULL,
    numero character varying(50) NOT NULL,
    plan_id integer,
    asset_id integer NOT NULL,
    tecnico_id integer,
    solicitante_id integer,
    status public.orderstatus NOT NULL,
    prioridade public.maintenancepriority NOT NULL,
    criticidade public.maintenancecriticality NOT NULL,
    tipo public.maintenancetype NOT NULL,
    data_abertura timestamp without time zone NOT NULL,
    data_agendada timestamp without time zone,
    data_inicio timestamp without time zone,
    data_pausa timestamp without time zone,
    data_conclusao timestamp without time zone,
    tempo_total_minutos integer,
    observacoes text,
    solucao text,
    custo_total numeric(10,2),
    service_ticket_id integer
);


ALTER TABLE public.maintenance_orders OWNER TO "user";

--
-- Name: maintenance_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_orders_id_seq OWNER TO "user";

--
-- Name: maintenance_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_orders_id_seq OWNED BY public.maintenance_orders.id;


--
-- Name: maintenance_photos; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_photos (
    id integer NOT NULL,
    order_id integer NOT NULL,
    execution_id integer,
    tipo public.phototype NOT NULL,
    caminho_arquivo character varying(255) NOT NULL,
    descricao text,
    data_upload timestamp without time zone NOT NULL,
    upload_por_id integer
);


ALTER TABLE public.maintenance_photos OWNER TO "user";

--
-- Name: maintenance_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_photos_id_seq OWNER TO "user";

--
-- Name: maintenance_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_photos_id_seq OWNED BY public.maintenance_photos.id;


--
-- Name: maintenance_plan_assets; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_plan_assets (
    id integer NOT NULL,
    plan_id integer NOT NULL,
    asset_id integer NOT NULL
);


ALTER TABLE public.maintenance_plan_assets OWNER TO "user";

--
-- Name: maintenance_plan_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_plan_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_plan_assets_id_seq OWNER TO "user";

--
-- Name: maintenance_plan_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_plan_assets_id_seq OWNED BY public.maintenance_plan_assets.id;


--
-- Name: maintenance_plans; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.maintenance_plans (
    id integer NOT NULL,
    nome character varying(200) NOT NULL,
    codigo character varying(50) NOT NULL,
    descricao text,
    tipo public.maintenancetype NOT NULL,
    periodicidade public.maintenanceperiodicity NOT NULL,
    dias_personalizado integer,
    tempo_estimado_horas numeric(5,2),
    criticidade public.maintenancecriticality NOT NULL,
    prioridade public.maintenancepriority NOT NULL,
    ativo boolean NOT NULL,
    responsavel_id integer,
    departamento_id integer,
    categoria_id integer,
    data_criacao timestamp without time zone NOT NULL,
    data_ultima_execucao timestamp without time zone,
    proxima_execucao timestamp without time zone NOT NULL
);


ALTER TABLE public.maintenance_plans OWNER TO "user";

--
-- Name: maintenance_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.maintenance_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_plans_id_seq OWNER TO "user";

--
-- Name: maintenance_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.maintenance_plans_id_seq OWNED BY public.maintenance_plans.id;


--
-- Name: manutencoes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.manutencoes (
    id integer NOT NULL,
    asset_id integer NOT NULL,
    responsavel_id integer,
    motivo text NOT NULL,
    tipo public.tipomanutencao NOT NULL,
    data_entrada timestamp without time zone NOT NULL,
    data_previsao timestamp without time zone,
    data_conclusao timestamp without time zone,
    status public.statusmanutencao NOT NULL,
    observacao_conclusao text,
    custo double precision,
    destino_tipo public.destinomanutencao,
    destino_user_id integer
);


ALTER TABLE public.manutencoes OWNER TO "user";

--
-- Name: manutencoes_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.manutencoes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manutencoes_id_seq OWNER TO "user";

--
-- Name: manutencoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.manutencoes_id_seq OWNED BY public.manutencoes.id;


--
-- Name: material_stock_transactions; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.material_stock_transactions (
    id integer NOT NULL,
    product_id integer NOT NULL,
    quantidade numeric(10,2) NOT NULL,
    tipo_movimentacao character varying(20) NOT NULL,
    origem_tabela character varying(50),
    origem_id integer,
    data_transacao timestamp without time zone NOT NULL,
    user_id integer NOT NULL,
    justificativa character varying(255)
);


ALTER TABLE public.material_stock_transactions OWNER TO "user";

--
-- Name: material_stock_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.material_stock_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.material_stock_transactions_id_seq OWNER TO "user";

--
-- Name: material_stock_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.material_stock_transactions_id_seq OWNED BY public.material_stock_transactions.id;


--
-- Name: material_stocks; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.material_stocks (
    id integer NOT NULL,
    product_id integer NOT NULL,
    quantidade_saldo numeric(10,2) NOT NULL,
    localizacao_almoxarifado character varying(100)
);


ALTER TABLE public.material_stocks OWNER TO "user";

--
-- Name: material_stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.material_stocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.material_stocks_id_seq OWNER TO "user";

--
-- Name: material_stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.material_stocks_id_seq OWNED BY public.material_stocks.id;


--
-- Name: movimentacoes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.movimentacoes (
    id integer NOT NULL,
    asset_id integer NOT NULL,
    data timestamp without time zone NOT NULL,
    tipo public.tipomovimentacao NOT NULL,
    de_user_id integer,
    para_user_id integer,
    de_departamento_id integer,
    para_departamento_id integer,
    observacao text
);


ALTER TABLE public.movimentacoes OWNER TO "user";

--
-- Name: movimentacoes_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.movimentacoes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.movimentacoes_id_seq OWNER TO "user";

--
-- Name: movimentacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.movimentacoes_id_seq OWNED BY public.movimentacoes.id;


--
-- Name: notas_fiscais; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.notas_fiscais (
    id integer NOT NULL,
    numero_nota character varying NOT NULL,
    fornecedor_id integer NOT NULL,
    xml_path character varying,
    data_cadastro timestamp without time zone NOT NULL,
    data_emissao timestamp without time zone,
    valor_total double precision,
    natureza_operacao character varying,
    emitente_nome character varying,
    emitente_cnpj character varying,
    destinatario_nome character varying,
    destinatario_cnpj character varying,
    itens json
);


ALTER TABLE public.notas_fiscais OWNER TO "user";

--
-- Name: notas_fiscais_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.notas_fiscais_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notas_fiscais_id_seq OWNER TO "user";

--
-- Name: notas_fiscais_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.notas_fiscais_id_seq OWNED BY public.notas_fiscais.id;


--
-- Name: purchase_approvals; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_approvals (
    id integer NOT NULL,
    request_id integer NOT NULL,
    nivel character varying(50) NOT NULL,
    aprovador_id integer,
    status character varying(20) NOT NULL,
    observacao text,
    data_decisao timestamp without time zone
);


ALTER TABLE public.purchase_approvals OWNER TO "user";

--
-- Name: purchase_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_approvals_id_seq OWNER TO "user";

--
-- Name: purchase_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_approvals_id_seq OWNED BY public.purchase_approvals.id;


--
-- Name: purchase_attachments; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_attachments (
    id integer NOT NULL,
    tabela_origem character varying(50) NOT NULL,
    registro_id integer NOT NULL,
    arquivo_path character varying(255) NOT NULL,
    nome_original character varying(150) NOT NULL,
    tipo_arquivo character varying(50) NOT NULL,
    data_envio timestamp without time zone NOT NULL
);


ALTER TABLE public.purchase_attachments OWNER TO "user";

--
-- Name: purchase_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_attachments_id_seq OWNER TO "user";

--
-- Name: purchase_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_attachments_id_seq OWNED BY public.purchase_attachments.id;


--
-- Name: purchase_categories; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_categories (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(255),
    ativo boolean NOT NULL
);


ALTER TABLE public.purchase_categories OWNER TO "user";

--
-- Name: purchase_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_categories_id_seq OWNER TO "user";

--
-- Name: purchase_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_categories_id_seq OWNED BY public.purchase_categories.id;


--
-- Name: purchase_contracts; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_contracts (
    id integer NOT NULL,
    fornecedor_id integer NOT NULL,
    tipo character varying(50) NOT NULL,
    numero character varying(100) NOT NULL,
    data_inicio timestamp without time zone NOT NULL,
    data_fim timestamp without time zone NOT NULL,
    renovacao_automatica boolean NOT NULL,
    valor numeric(12,2) NOT NULL,
    periodicidade character varying(50) NOT NULL,
    arquivo_pdf_path character varying(255),
    alertado_dias integer
);


ALTER TABLE public.purchase_contracts OWNER TO "user";

--
-- Name: purchase_contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_contracts_id_seq OWNER TO "user";

--
-- Name: purchase_contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_contracts_id_seq OWNED BY public.purchase_contracts.id;


--
-- Name: purchase_history; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_history (
    id integer NOT NULL,
    tabela_origem character varying(50) NOT NULL,
    registro_id integer NOT NULL,
    user_id integer NOT NULL,
    acao character varying(100) NOT NULL,
    data_acao timestamp without time zone NOT NULL,
    ip_address character varying(45),
    observacoes text
);


ALTER TABLE public.purchase_history OWNER TO "user";

--
-- Name: purchase_history_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_history_id_seq OWNER TO "user";

--
-- Name: purchase_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_history_id_seq OWNED BY public.purchase_history.id;


--
-- Name: purchase_notifications; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    mensagem text NOT NULL,
    lido boolean NOT NULL,
    data_criacao timestamp without time zone NOT NULL,
    link_redirecionamento character varying(255)
);


ALTER TABLE public.purchase_notifications OWNER TO "user";

--
-- Name: purchase_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_notifications_id_seq OWNER TO "user";

--
-- Name: purchase_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_notifications_id_seq OWNED BY public.purchase_notifications.id;


--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantidade numeric(10,2) NOT NULL,
    valor_unitario numeric(10,2) NOT NULL,
    total_item numeric(12,2) NOT NULL
);


ALTER TABLE public.purchase_order_items OWNER TO "user";

--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_order_items_id_seq OWNER TO "user";

--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_order_items_id_seq OWNED BY public.purchase_order_items.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_orders (
    id integer NOT NULL,
    numero character varying(50) NOT NULL,
    fornecedor_id integer NOT NULL,
    centro_custo_id integer NOT NULL,
    request_id integer,
    quotation_id integer,
    valor_total numeric(12,2) NOT NULL,
    desconto numeric(10,2) NOT NULL,
    ipi numeric(10,2) NOT NULL,
    icms numeric(10,2) NOT NULL,
    frete numeric(10,2) NOT NULL,
    status public.purchaseorderstatus NOT NULL,
    data_emissao timestamp without time zone NOT NULL
);


ALTER TABLE public.purchase_orders OWNER TO "user";

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_orders_id_seq OWNER TO "user";

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_orders_id_seq OWNED BY public.purchase_orders.id;


--
-- Name: purchase_products; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_products (
    id integer NOT NULL,
    codigo character varying(50) NOT NULL,
    nome character varying(150) NOT NULL,
    categoria_id integer NOT NULL,
    unidade character varying(20) NOT NULL,
    marca character varying(50),
    modelo character varying(50),
    fabricante character varying(50),
    descricao text,
    tipo public.producttype NOT NULL,
    imagem_path character varying(255),
    ativo boolean NOT NULL
);


ALTER TABLE public.purchase_products OWNER TO "user";

--
-- Name: purchase_products_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_products_id_seq OWNER TO "user";

--
-- Name: purchase_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_products_id_seq OWNED BY public.purchase_products.id;


--
-- Name: purchase_quotation_items; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_quotation_items (
    id integer NOT NULL,
    quotation_supplier_id integer NOT NULL,
    product_id integer NOT NULL,
    quantidade numeric(10,2) NOT NULL,
    valor_unitario numeric(10,2) NOT NULL
);


ALTER TABLE public.purchase_quotation_items OWNER TO "user";

--
-- Name: purchase_quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_quotation_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_quotation_items_id_seq OWNER TO "user";

--
-- Name: purchase_quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_quotation_items_id_seq OWNED BY public.purchase_quotation_items.id;


--
-- Name: purchase_quotation_suppliers; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_quotation_suppliers (
    id integer NOT NULL,
    quotation_id integer NOT NULL,
    fornecedor_id integer NOT NULL,
    valor_total numeric(12,2) NOT NULL,
    frete numeric(10,2) NOT NULL,
    prazo_entrega_dias integer NOT NULL,
    garantia_meses integer NOT NULL,
    forma_pagamento character varying(100),
    observacoes text,
    escolhido boolean NOT NULL
);


ALTER TABLE public.purchase_quotation_suppliers OWNER TO "user";

--
-- Name: purchase_quotation_suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_quotation_suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_quotation_suppliers_id_seq OWNER TO "user";

--
-- Name: purchase_quotation_suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_quotation_suppliers_id_seq OWNED BY public.purchase_quotation_suppliers.id;


--
-- Name: purchase_quotations; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_quotations (
    id integer NOT NULL,
    numero character varying(50) NOT NULL,
    request_id integer NOT NULL,
    data_criacao timestamp without time zone NOT NULL,
    status character varying(20) NOT NULL
);


ALTER TABLE public.purchase_quotations OWNER TO "user";

--
-- Name: purchase_quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_quotations_id_seq OWNER TO "user";

--
-- Name: purchase_quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_quotations_id_seq OWNED BY public.purchase_quotations.id;


--
-- Name: purchase_receiving_items; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_receiving_items (
    id integer NOT NULL,
    receiving_id integer NOT NULL,
    product_id integer NOT NULL,
    quantidade_recebida numeric(10,2) NOT NULL,
    divergencias character varying(255),
    estoque_atualizado boolean NOT NULL,
    ativo_criado_id integer
);


ALTER TABLE public.purchase_receiving_items OWNER TO "user";

--
-- Name: purchase_receiving_items_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_receiving_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_receiving_items_id_seq OWNER TO "user";

--
-- Name: purchase_receiving_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_receiving_items_id_seq OWNED BY public.purchase_receiving_items.id;


--
-- Name: purchase_receivings; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_receivings (
    id integer NOT NULL,
    order_id integer NOT NULL,
    data_recebimento timestamp without time zone NOT NULL,
    responsavel_id integer NOT NULL,
    nota_fiscal_id integer,
    observacoes text
);


ALTER TABLE public.purchase_receivings OWNER TO "user";

--
-- Name: purchase_receivings_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_receivings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_receivings_id_seq OWNER TO "user";

--
-- Name: purchase_receivings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_receivings_id_seq OWNED BY public.purchase_receivings.id;


--
-- Name: purchase_request_items; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_request_items (
    id integer NOT NULL,
    request_id integer NOT NULL,
    product_id integer NOT NULL,
    quantidade numeric(10,2) NOT NULL,
    valor_estimado numeric(10,2) NOT NULL,
    fornecedor_sugerido_id integer,
    observacao character varying(255)
);


ALTER TABLE public.purchase_request_items OWNER TO "user";

--
-- Name: purchase_request_items_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_request_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_request_items_id_seq OWNER TO "user";

--
-- Name: purchase_request_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_request_items_id_seq OWNED BY public.purchase_request_items.id;


--
-- Name: purchase_requests; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_requests (
    id integer NOT NULL,
    numero character varying(50) NOT NULL,
    solicitante_id integer NOT NULL,
    departamento_id integer NOT NULL,
    centro_custo_id integer NOT NULL,
    justificativa text NOT NULL,
    urgencia character varying(20) NOT NULL,
    data_necessaria timestamp without time zone,
    status public.purchaserequeststatus NOT NULL,
    data_criacao timestamp without time zone NOT NULL,
    origem_os_id integer,
    origem_ticket_id integer
);


ALTER TABLE public.purchase_requests OWNER TO "user";

--
-- Name: purchase_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_requests_id_seq OWNER TO "user";

--
-- Name: purchase_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_requests_id_seq OWNED BY public.purchase_requests.id;


--
-- Name: purchase_units; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.purchase_units (
    id integer NOT NULL,
    sigla character varying(20) NOT NULL,
    descricao character varying(100)
);


ALTER TABLE public.purchase_units OWNER TO "user";

--
-- Name: purchase_units_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.purchase_units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_units_id_seq OWNER TO "user";

--
-- Name: purchase_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.purchase_units_id_seq OWNED BY public.purchase_units.id;


--
-- Name: qr_logs; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.qr_logs (
    id integer NOT NULL,
    user_id integer,
    actor_id integer,
    action public.qrlogaction NOT NULL,
    ip_address character varying,
    details character varying,
    success boolean NOT NULL,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.qr_logs OWNER TO "user";

--
-- Name: qr_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.qr_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qr_logs_id_seq OWNER TO "user";

--
-- Name: qr_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.qr_logs_id_seq OWNED BY public.qr_logs.id;


--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.service_categories (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    setor character varying(50) NOT NULL
);


ALTER TABLE public.service_categories OWNER TO "user";

--
-- Name: service_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.service_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_categories_id_seq OWNER TO "user";

--
-- Name: service_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.service_categories_id_seq OWNED BY public.service_categories.id;


--
-- Name: service_definitions; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.service_definitions (
    id integer NOT NULL,
    categoria_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    prioridade_padrao character varying(20) NOT NULL,
    tempo_estimado_horas double precision
);


ALTER TABLE public.service_definitions OWNER TO "user";

--
-- Name: service_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.service_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_definitions_id_seq OWNER TO "user";

--
-- Name: service_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.service_definitions_id_seq OWNED BY public.service_definitions.id;


--
-- Name: service_ticket_interactions; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.service_ticket_interactions (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    usuario_id integer NOT NULL,
    mensagem text NOT NULL,
    foto character varying(255),
    data_criacao timestamp without time zone NOT NULL,
    tipo character varying(50) NOT NULL
);


ALTER TABLE public.service_ticket_interactions OWNER TO "user";

--
-- Name: service_ticket_interactions_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.service_ticket_interactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_ticket_interactions_id_seq OWNER TO "user";

--
-- Name: service_ticket_interactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.service_ticket_interactions_id_seq OWNED BY public.service_ticket_interactions.id;


--
-- Name: service_tickets; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.service_tickets (
    id integer NOT NULL,
    codigo character varying(20) NOT NULL,
    servico_id integer NOT NULL,
    solicitante_id integer NOT NULL,
    tecnico_id integer,
    titulo character varying(200) NOT NULL,
    descricao text NOT NULL,
    status character varying(30) NOT NULL,
    prioridade character varying(20) NOT NULL,
    foto character varying(255),
    data_abertura timestamp without time zone NOT NULL,
    data_atualizacao timestamp without time zone NOT NULL,
    data_fechamento timestamp without time zone,
    solucao text,
    feedback_usuario text,
    avaliacao integer
);


ALTER TABLE public.service_tickets OWNER TO "user";

--
-- Name: service_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.service_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_tickets_id_seq OWNER TO "user";

--
-- Name: service_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.service_tickets_id_seq OWNED BY public.service_tickets.id;


--
-- Name: solicitacoes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.solicitacoes (
    id integer NOT NULL,
    solicitante_id integer,
    asset_id integer,
    data_solicitacao timestamp without time zone NOT NULL,
    motivo text NOT NULL,
    status public.statussolicitacao NOT NULL,
    aprovador_id integer,
    data_aprovacao timestamp without time zone,
    data_prevista_devolucao timestamp without time zone,
    data_entrega timestamp without time zone,
    confirmado_por_id integer,
    confirmado_via_qr boolean,
    observacao_entrega text
);


ALTER TABLE public.solicitacoes OWNER TO "user";

--
-- Name: solicitacoes_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.solicitacoes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.solicitacoes_id_seq OWNER TO "user";

--
-- Name: solicitacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.solicitacoes_id_seq OWNED BY public.solicitacoes.id;


--
-- Name: solicitacoes_manutencao; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.solicitacoes_manutencao (
    id integer NOT NULL,
    solicitante_id integer,
    asset_id integer NOT NULL,
    descricao text NOT NULL,
    prioridade public.prioridadesolicitacao NOT NULL,
    data_solicitacao timestamp without time zone NOT NULL,
    data_resposta timestamp without time zone,
    data_conclusao_tecnico timestamp without time zone,
    data_entrega timestamp without time zone,
    status public.statussolicitacaomanutencao NOT NULL,
    responsavel_id integer,
    observacao_resposta text,
    manutencao_id integer
);


ALTER TABLE public.solicitacoes_manutencao OWNER TO "user";

--
-- Name: solicitacoes_manutencao_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.solicitacoes_manutencao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.solicitacoes_manutencao_id_seq OWNER TO "user";

--
-- Name: solicitacoes_manutencao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.solicitacoes_manutencao_id_seq OWNED BY public.solicitacoes_manutencao.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key character varying NOT NULL,
    setting_value character varying NOT NULL,
    descricao character varying
);


ALTER TABLE public.system_settings OWNER TO "user";

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_settings_id_seq OWNER TO "user";

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying NOT NULL,
    hashed_password character varying NOT NULL,
    nome character varying NOT NULL,
    matricula character varying,
    cargo character varying,
    role public.userrole NOT NULL,
    is_active boolean NOT NULL,
    avatar_url character varying,
    qr_token character varying,
    qr_token_created_at timestamp without time zone,
    pin_hash character varying,
    departamento_id integer
);


ALTER TABLE public.users OWNER TO "user";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO "user";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: armazenamentos id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.armazenamentos ALTER COLUMN id SET DEFAULT nextval('public.armazenamentos_id_seq'::regclass);


--
-- Name: asset_categories id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.asset_categories ALTER COLUMN id SET DEFAULT nextval('public.asset_categories_id_seq'::regclass);


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.assets_id_seq'::regclass);


--
-- Name: cost_centers id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.cost_centers ALTER COLUMN id SET DEFAULT nextval('public.cost_centers_id_seq'::regclass);


--
-- Name: departamentos id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.departamentos ALTER COLUMN id SET DEFAULT nextval('public.departamentos_id_seq'::regclass);


--
-- Name: fornecedores id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fornecedores ALTER COLUMN id SET DEFAULT nextval('public.fornecedores_id_seq'::regclass);


--
-- Name: locais id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.locais ALTER COLUMN id SET DEFAULT nextval('public.locais_id_seq'::regclass);


--
-- Name: maintenance_checklist_items id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_checklist_items ALTER COLUMN id SET DEFAULT nextval('public.maintenance_checklist_items_id_seq'::regclass);


--
-- Name: maintenance_checklists id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_checklists ALTER COLUMN id SET DEFAULT nextval('public.maintenance_checklists_id_seq'::regclass);


--
-- Name: maintenance_executions id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_executions ALTER COLUMN id SET DEFAULT nextval('public.maintenance_executions_id_seq'::regclass);


--
-- Name: maintenance_history id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_history ALTER COLUMN id SET DEFAULT nextval('public.maintenance_history_id_seq'::regclass);


--
-- Name: maintenance_materials id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_materials ALTER COLUMN id SET DEFAULT nextval('public.maintenance_materials_id_seq'::regclass);


--
-- Name: maintenance_notifications id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_notifications ALTER COLUMN id SET DEFAULT nextval('public.maintenance_notifications_id_seq'::regclass);


--
-- Name: maintenance_orders id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_orders ALTER COLUMN id SET DEFAULT nextval('public.maintenance_orders_id_seq'::regclass);


--
-- Name: maintenance_photos id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_photos ALTER COLUMN id SET DEFAULT nextval('public.maintenance_photos_id_seq'::regclass);


--
-- Name: maintenance_plan_assets id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plan_assets ALTER COLUMN id SET DEFAULT nextval('public.maintenance_plan_assets_id_seq'::regclass);


--
-- Name: maintenance_plans id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plans ALTER COLUMN id SET DEFAULT nextval('public.maintenance_plans_id_seq'::regclass);


--
-- Name: manutencoes id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.manutencoes ALTER COLUMN id SET DEFAULT nextval('public.manutencoes_id_seq'::regclass);


--
-- Name: material_stock_transactions id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.material_stock_transactions ALTER COLUMN id SET DEFAULT nextval('public.material_stock_transactions_id_seq'::regclass);


--
-- Name: material_stocks id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.material_stocks ALTER COLUMN id SET DEFAULT nextval('public.material_stocks_id_seq'::regclass);


--
-- Name: movimentacoes id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movimentacoes ALTER COLUMN id SET DEFAULT nextval('public.movimentacoes_id_seq'::regclass);


--
-- Name: notas_fiscais id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.notas_fiscais ALTER COLUMN id SET DEFAULT nextval('public.notas_fiscais_id_seq'::regclass);


--
-- Name: purchase_approvals id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_approvals ALTER COLUMN id SET DEFAULT nextval('public.purchase_approvals_id_seq'::regclass);


--
-- Name: purchase_attachments id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_attachments ALTER COLUMN id SET DEFAULT nextval('public.purchase_attachments_id_seq'::regclass);


--
-- Name: purchase_categories id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_categories ALTER COLUMN id SET DEFAULT nextval('public.purchase_categories_id_seq'::regclass);


--
-- Name: purchase_contracts id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_contracts ALTER COLUMN id SET DEFAULT nextval('public.purchase_contracts_id_seq'::regclass);


--
-- Name: purchase_history id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_history ALTER COLUMN id SET DEFAULT nextval('public.purchase_history_id_seq'::regclass);


--
-- Name: purchase_notifications id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_notifications ALTER COLUMN id SET DEFAULT nextval('public.purchase_notifications_id_seq'::regclass);


--
-- Name: purchase_order_items id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_order_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_order_items_id_seq'::regclass);


--
-- Name: purchase_orders id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.purchase_orders_id_seq'::regclass);


--
-- Name: purchase_products id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_products ALTER COLUMN id SET DEFAULT nextval('public.purchase_products_id_seq'::regclass);


--
-- Name: purchase_quotation_items id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotation_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_quotation_items_id_seq'::regclass);


--
-- Name: purchase_quotation_suppliers id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotation_suppliers ALTER COLUMN id SET DEFAULT nextval('public.purchase_quotation_suppliers_id_seq'::regclass);


--
-- Name: purchase_quotations id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotations ALTER COLUMN id SET DEFAULT nextval('public.purchase_quotations_id_seq'::regclass);


--
-- Name: purchase_receiving_items id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receiving_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_receiving_items_id_seq'::regclass);


--
-- Name: purchase_receivings id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receivings ALTER COLUMN id SET DEFAULT nextval('public.purchase_receivings_id_seq'::regclass);


--
-- Name: purchase_request_items id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_request_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_request_items_id_seq'::regclass);


--
-- Name: purchase_requests id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_requests ALTER COLUMN id SET DEFAULT nextval('public.purchase_requests_id_seq'::regclass);


--
-- Name: purchase_units id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_units ALTER COLUMN id SET DEFAULT nextval('public.purchase_units_id_seq'::regclass);


--
-- Name: qr_logs id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.qr_logs ALTER COLUMN id SET DEFAULT nextval('public.qr_logs_id_seq'::regclass);


--
-- Name: service_categories id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_categories ALTER COLUMN id SET DEFAULT nextval('public.service_categories_id_seq'::regclass);


--
-- Name: service_definitions id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_definitions ALTER COLUMN id SET DEFAULT nextval('public.service_definitions_id_seq'::regclass);


--
-- Name: service_ticket_interactions id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_ticket_interactions ALTER COLUMN id SET DEFAULT nextval('public.service_ticket_interactions_id_seq'::regclass);


--
-- Name: service_tickets id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_tickets ALTER COLUMN id SET DEFAULT nextval('public.service_tickets_id_seq'::regclass);


--
-- Name: solicitacoes id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes ALTER COLUMN id SET DEFAULT nextval('public.solicitacoes_id_seq'::regclass);


--
-- Name: solicitacoes_manutencao id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes_manutencao ALTER COLUMN id SET DEFAULT nextval('public.solicitacoes_manutencao_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: armazenamentos; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.armazenamentos (id, nome, capacidade_max, tipo_itens) FROM stdin;
\.


--
-- Data for Name: asset_categories; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.asset_categories (id, nome, descricao) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.assets (id, nome, e_patrimonio, modelo, descricao, data_aquisicao, valor, status, qr_code_path, foto_path, numero_serie, em_posse_de, bloqueado, categoria_id, created_by_id, fornecedor_id, nota_fiscal_id, current_user_id, current_departamento_id, current_local_id, current_armazenamento_id) FROM stdin;
\.


--
-- Data for Name: cost_centers; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.cost_centers (id, codigo, nome, departamento_id, responsavel_id, orcamento_anual, orcamento_mensal, orcamento_anual_usado, orcamento_mensal_usado, alerta_limite, bloquear_limite) FROM stdin;
\.


--
-- Data for Name: departamentos; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.departamentos (id, nome, responsavel_id) FROM stdin;
\.


--
-- Data for Name: fornecedores; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.fornecedores (id, nome, razao_social, cnpj, email, telefone, endereco, cidade, estado, tipo_fornecedor) FROM stdin;
\.


--
-- Data for Name: locais; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.locais (id, nome, departamento_id) FROM stdin;
\.


--
-- Data for Name: maintenance_checklist_items; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_checklist_items (id, checklist_id, descricao, obrigatorio, ordem, requer_foto) FROM stdin;
\.


--
-- Data for Name: maintenance_checklists; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_checklists (id, plan_id, nome, ordem) FROM stdin;
\.


--
-- Data for Name: maintenance_executions; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_executions (id, order_id, checklist_item_id, concluido, observacao, data_execucao, executado_por_id) FROM stdin;
\.


--
-- Data for Name: maintenance_history; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_history (id, order_id, acao, descricao, usuario_id, data_hora, status_anterior, status_novo) FROM stdin;
\.


--
-- Data for Name: maintenance_materials; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_materials (id, order_id, produto, quantidade, valor_unitario, valor_total, observacao) FROM stdin;
\.


--
-- Data for Name: maintenance_notifications; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_notifications (id, order_id, plan_id, usuario_id, tipo, mensagem, lida, data_criacao) FROM stdin;
\.


--
-- Data for Name: maintenance_orders; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_orders (id, numero, plan_id, asset_id, tecnico_id, solicitante_id, status, prioridade, criticidade, tipo, data_abertura, data_agendada, data_inicio, data_pausa, data_conclusao, tempo_total_minutos, observacoes, solucao, custo_total, service_ticket_id) FROM stdin;
\.


--
-- Data for Name: maintenance_photos; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_photos (id, order_id, execution_id, tipo, caminho_arquivo, descricao, data_upload, upload_por_id) FROM stdin;
\.


--
-- Data for Name: maintenance_plan_assets; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_plan_assets (id, plan_id, asset_id) FROM stdin;
\.


--
-- Data for Name: maintenance_plans; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.maintenance_plans (id, nome, codigo, descricao, tipo, periodicidade, dias_personalizado, tempo_estimado_horas, criticidade, prioridade, ativo, responsavel_id, departamento_id, categoria_id, data_criacao, data_ultima_execucao, proxima_execucao) FROM stdin;
\.


--
-- Data for Name: manutencoes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.manutencoes (id, asset_id, responsavel_id, motivo, tipo, data_entrada, data_previsao, data_conclusao, status, observacao_conclusao, custo, destino_tipo, destino_user_id) FROM stdin;
\.


--
-- Data for Name: material_stock_transactions; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.material_stock_transactions (id, product_id, quantidade, tipo_movimentacao, origem_tabela, origem_id, data_transacao, user_id, justificativa) FROM stdin;
\.


--
-- Data for Name: material_stocks; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.material_stocks (id, product_id, quantidade_saldo, localizacao_almoxarifado) FROM stdin;
\.


--
-- Data for Name: movimentacoes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.movimentacoes (id, asset_id, data, tipo, de_user_id, para_user_id, de_departamento_id, para_departamento_id, observacao) FROM stdin;
\.


--
-- Data for Name: notas_fiscais; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.notas_fiscais (id, numero_nota, fornecedor_id, xml_path, data_cadastro, data_emissao, valor_total, natureza_operacao, emitente_nome, emitente_cnpj, destinatario_nome, destinatario_cnpj, itens) FROM stdin;
\.


--
-- Data for Name: purchase_approvals; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_approvals (id, request_id, nivel, aprovador_id, status, observacao, data_decisao) FROM stdin;
\.


--
-- Data for Name: purchase_attachments; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_attachments (id, tabela_origem, registro_id, arquivo_path, nome_original, tipo_arquivo, data_envio) FROM stdin;
\.


--
-- Data for Name: purchase_categories; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_categories (id, nome, descricao, ativo) FROM stdin;
\.


--
-- Data for Name: purchase_contracts; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_contracts (id, fornecedor_id, tipo, numero, data_inicio, data_fim, renovacao_automatica, valor, periodicidade, arquivo_pdf_path, alertado_dias) FROM stdin;
\.


--
-- Data for Name: purchase_history; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_history (id, tabela_origem, registro_id, user_id, acao, data_acao, ip_address, observacoes) FROM stdin;
\.


--
-- Data for Name: purchase_notifications; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_notifications (id, user_id, mensagem, lido, data_criacao, link_redirecionamento) FROM stdin;
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_order_items (id, order_id, product_id, quantidade, valor_unitario, total_item) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_orders (id, numero, fornecedor_id, centro_custo_id, request_id, quotation_id, valor_total, desconto, ipi, icms, frete, status, data_emissao) FROM stdin;
\.


--
-- Data for Name: purchase_products; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_products (id, codigo, nome, categoria_id, unidade, marca, modelo, fabricante, descricao, tipo, imagem_path, ativo) FROM stdin;
\.


--
-- Data for Name: purchase_quotation_items; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_quotation_items (id, quotation_supplier_id, product_id, quantidade, valor_unitario) FROM stdin;
\.


--
-- Data for Name: purchase_quotation_suppliers; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_quotation_suppliers (id, quotation_id, fornecedor_id, valor_total, frete, prazo_entrega_dias, garantia_meses, forma_pagamento, observacoes, escolhido) FROM stdin;
\.


--
-- Data for Name: purchase_quotations; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_quotations (id, numero, request_id, data_criacao, status) FROM stdin;
\.


--
-- Data for Name: purchase_receiving_items; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_receiving_items (id, receiving_id, product_id, quantidade_recebida, divergencias, estoque_atualizado, ativo_criado_id) FROM stdin;
\.


--
-- Data for Name: purchase_receivings; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_receivings (id, order_id, data_recebimento, responsavel_id, nota_fiscal_id, observacoes) FROM stdin;
\.


--
-- Data for Name: purchase_request_items; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_request_items (id, request_id, product_id, quantidade, valor_estimado, fornecedor_sugerido_id, observacao) FROM stdin;
\.


--
-- Data for Name: purchase_requests; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_requests (id, numero, solicitante_id, departamento_id, centro_custo_id, justificativa, urgencia, data_necessaria, status, data_criacao, origem_os_id, origem_ticket_id) FROM stdin;
\.


--
-- Data for Name: purchase_units; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.purchase_units (id, sigla, descricao) FROM stdin;
\.


--
-- Data for Name: qr_logs; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.qr_logs (id, user_id, actor_id, action, ip_address, details, success, "timestamp") FROM stdin;
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.service_categories (id, nome, descricao, setor) FROM stdin;
\.


--
-- Data for Name: service_definitions; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.service_definitions (id, categoria_id, nome, descricao, prioridade_padrao, tempo_estimado_horas) FROM stdin;
\.


--
-- Data for Name: service_ticket_interactions; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.service_ticket_interactions (id, ticket_id, usuario_id, mensagem, foto, data_criacao, tipo) FROM stdin;
\.


--
-- Data for Name: service_tickets; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.service_tickets (id, codigo, servico_id, solicitante_id, tecnico_id, titulo, descricao, status, prioridade, foto, data_abertura, data_atualizacao, data_fechamento, solucao, feedback_usuario, avaliacao) FROM stdin;
\.


--
-- Data for Name: solicitacoes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.solicitacoes (id, solicitante_id, asset_id, data_solicitacao, motivo, status, aprovador_id, data_aprovacao, data_prevista_devolucao, data_entrega, confirmado_por_id, confirmado_via_qr, observacao_entrega) FROM stdin;
\.


--
-- Data for Name: solicitacoes_manutencao; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.solicitacoes_manutencao (id, solicitante_id, asset_id, descricao, prioridade, data_solicitacao, data_resposta, data_conclusao_tecnico, data_entrega, status, responsavel_id, observacao_resposta, manutencao_id) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.system_settings (id, setting_key, setting_value, descricao) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.users (id, email, hashed_password, nome, matricula, cargo, role, is_active, avatar_url, qr_token, qr_token_created_at, pin_hash, departamento_id) FROM stdin;
1	admin@example.com	$2b$12$gtBszuyVwWTKMBr7yV7Oo.bbZ2SVZAF2jNmKnWgXvaEMBFTLD7AVC	Administrador	\N	\N	ADMIN	t	\N	\N	\N	\N	\N
\.


--
-- Name: armazenamentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.armazenamentos_id_seq', 1, false);


--
-- Name: asset_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.asset_categories_id_seq', 1, false);


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.assets_id_seq', 1, false);


--
-- Name: cost_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.cost_centers_id_seq', 1, false);


--
-- Name: departamentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.departamentos_id_seq', 1, false);


--
-- Name: fornecedores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.fornecedores_id_seq', 1, false);


--
-- Name: locais_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.locais_id_seq', 1, false);


--
-- Name: maintenance_checklist_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_checklist_items_id_seq', 1, false);


--
-- Name: maintenance_checklists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_checklists_id_seq', 1, false);


--
-- Name: maintenance_executions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_executions_id_seq', 1, false);


--
-- Name: maintenance_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_history_id_seq', 1, false);


--
-- Name: maintenance_materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_materials_id_seq', 1, false);


--
-- Name: maintenance_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_notifications_id_seq', 1, false);


--
-- Name: maintenance_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_orders_id_seq', 1, false);


--
-- Name: maintenance_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_photos_id_seq', 1, false);


--
-- Name: maintenance_plan_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_plan_assets_id_seq', 1, false);


--
-- Name: maintenance_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.maintenance_plans_id_seq', 1, false);


--
-- Name: manutencoes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.manutencoes_id_seq', 1, false);


--
-- Name: material_stock_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.material_stock_transactions_id_seq', 1, false);


--
-- Name: material_stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.material_stocks_id_seq', 1, false);


--
-- Name: movimentacoes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.movimentacoes_id_seq', 1, false);


--
-- Name: notas_fiscais_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.notas_fiscais_id_seq', 1, false);


--
-- Name: purchase_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_approvals_id_seq', 1, false);


--
-- Name: purchase_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_attachments_id_seq', 1, false);


--
-- Name: purchase_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_categories_id_seq', 1, false);


--
-- Name: purchase_contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_contracts_id_seq', 1, false);


--
-- Name: purchase_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_history_id_seq', 1, false);


--
-- Name: purchase_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_notifications_id_seq', 1, false);


--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_order_items_id_seq', 1, false);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 1, false);


--
-- Name: purchase_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_products_id_seq', 1, false);


--
-- Name: purchase_quotation_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_quotation_items_id_seq', 1, false);


--
-- Name: purchase_quotation_suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_quotation_suppliers_id_seq', 1, false);


--
-- Name: purchase_quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_quotations_id_seq', 1, false);


--
-- Name: purchase_receiving_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_receiving_items_id_seq', 1, false);


--
-- Name: purchase_receivings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_receivings_id_seq', 1, false);


--
-- Name: purchase_request_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_request_items_id_seq', 1, false);


--
-- Name: purchase_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_requests_id_seq', 1, false);


--
-- Name: purchase_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.purchase_units_id_seq', 1, false);


--
-- Name: qr_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.qr_logs_id_seq', 1, false);


--
-- Name: service_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.service_categories_id_seq', 1, false);


--
-- Name: service_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.service_definitions_id_seq', 1, false);


--
-- Name: service_ticket_interactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.service_ticket_interactions_id_seq', 1, false);


--
-- Name: service_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.service_tickets_id_seq', 1, false);


--
-- Name: solicitacoes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.solicitacoes_id_seq', 1, false);


--
-- Name: solicitacoes_manutencao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.solicitacoes_manutencao_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: armazenamentos armazenamentos_nome_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.armazenamentos
    ADD CONSTRAINT armazenamentos_nome_key UNIQUE (nome);


--
-- Name: armazenamentos armazenamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.armazenamentos
    ADD CONSTRAINT armazenamentos_pkey PRIMARY KEY (id);


--
-- Name: asset_categories asset_categories_nome_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.asset_categories
    ADD CONSTRAINT asset_categories_nome_key UNIQUE (nome);


--
-- Name: asset_categories asset_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.asset_categories
    ADD CONSTRAINT asset_categories_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: cost_centers cost_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_pkey PRIMARY KEY (id);


--
-- Name: departamentos departamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.departamentos
    ADD CONSTRAINT departamentos_pkey PRIMARY KEY (id);


--
-- Name: fornecedores fornecedores_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fornecedores
    ADD CONSTRAINT fornecedores_pkey PRIMARY KEY (id);


--
-- Name: locais locais_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.locais
    ADD CONSTRAINT locais_pkey PRIMARY KEY (id);


--
-- Name: maintenance_checklist_items maintenance_checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_checklist_items
    ADD CONSTRAINT maintenance_checklist_items_pkey PRIMARY KEY (id);


--
-- Name: maintenance_checklists maintenance_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_checklists
    ADD CONSTRAINT maintenance_checklists_pkey PRIMARY KEY (id);


--
-- Name: maintenance_executions maintenance_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_executions
    ADD CONSTRAINT maintenance_executions_pkey PRIMARY KEY (id);


--
-- Name: maintenance_history maintenance_history_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_pkey PRIMARY KEY (id);


--
-- Name: maintenance_materials maintenance_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_materials
    ADD CONSTRAINT maintenance_materials_pkey PRIMARY KEY (id);


--
-- Name: maintenance_notifications maintenance_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_notifications
    ADD CONSTRAINT maintenance_notifications_pkey PRIMARY KEY (id);


--
-- Name: maintenance_orders maintenance_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_orders
    ADD CONSTRAINT maintenance_orders_pkey PRIMARY KEY (id);


--
-- Name: maintenance_photos maintenance_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_photos
    ADD CONSTRAINT maintenance_photos_pkey PRIMARY KEY (id);


--
-- Name: maintenance_plan_assets maintenance_plan_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plan_assets
    ADD CONSTRAINT maintenance_plan_assets_pkey PRIMARY KEY (id);


--
-- Name: maintenance_plans maintenance_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plans
    ADD CONSTRAINT maintenance_plans_pkey PRIMARY KEY (id);


--
-- Name: manutencoes manutencoes_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.manutencoes
    ADD CONSTRAINT manutencoes_pkey PRIMARY KEY (id);


--
-- Name: material_stock_transactions material_stock_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.material_stock_transactions
    ADD CONSTRAINT material_stock_transactions_pkey PRIMARY KEY (id);


--
-- Name: material_stocks material_stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.material_stocks
    ADD CONSTRAINT material_stocks_pkey PRIMARY KEY (id);


--
-- Name: material_stocks material_stocks_product_id_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.material_stocks
    ADD CONSTRAINT material_stocks_product_id_key UNIQUE (product_id);


--
-- Name: movimentacoes movimentacoes_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_pkey PRIMARY KEY (id);


--
-- Name: notas_fiscais notas_fiscais_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.notas_fiscais
    ADD CONSTRAINT notas_fiscais_pkey PRIMARY KEY (id);


--
-- Name: purchase_approvals purchase_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_approvals
    ADD CONSTRAINT purchase_approvals_pkey PRIMARY KEY (id);


--
-- Name: purchase_attachments purchase_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_attachments
    ADD CONSTRAINT purchase_attachments_pkey PRIMARY KEY (id);


--
-- Name: purchase_categories purchase_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_categories
    ADD CONSTRAINT purchase_categories_pkey PRIMARY KEY (id);


--
-- Name: purchase_contracts purchase_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_contracts
    ADD CONSTRAINT purchase_contracts_pkey PRIMARY KEY (id);


--
-- Name: purchase_history purchase_history_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_history
    ADD CONSTRAINT purchase_history_pkey PRIMARY KEY (id);


--
-- Name: purchase_notifications purchase_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_notifications
    ADD CONSTRAINT purchase_notifications_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_products purchase_products_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_products
    ADD CONSTRAINT purchase_products_pkey PRIMARY KEY (id);


--
-- Name: purchase_quotation_items purchase_quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotation_items
    ADD CONSTRAINT purchase_quotation_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_quotation_suppliers purchase_quotation_suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotation_suppliers
    ADD CONSTRAINT purchase_quotation_suppliers_pkey PRIMARY KEY (id);


--
-- Name: purchase_quotations purchase_quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotations
    ADD CONSTRAINT purchase_quotations_pkey PRIMARY KEY (id);


--
-- Name: purchase_receiving_items purchase_receiving_items_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receiving_items
    ADD CONSTRAINT purchase_receiving_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_receivings purchase_receivings_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receivings
    ADD CONSTRAINT purchase_receivings_pkey PRIMARY KEY (id);


--
-- Name: purchase_request_items purchase_request_items_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_requests purchase_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_pkey PRIMARY KEY (id);


--
-- Name: purchase_units purchase_units_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_units
    ADD CONSTRAINT purchase_units_pkey PRIMARY KEY (id);


--
-- Name: qr_logs qr_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.qr_logs
    ADD CONSTRAINT qr_logs_pkey PRIMARY KEY (id);


--
-- Name: service_categories service_categories_nome_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_nome_key UNIQUE (nome);


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_pkey PRIMARY KEY (id);


--
-- Name: service_definitions service_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_definitions
    ADD CONSTRAINT service_definitions_pkey PRIMARY KEY (id);


--
-- Name: service_ticket_interactions service_ticket_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_ticket_interactions
    ADD CONSTRAINT service_ticket_interactions_pkey PRIMARY KEY (id);


--
-- Name: service_tickets service_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_pkey PRIMARY KEY (id);


--
-- Name: solicitacoes_manutencao solicitacoes_manutencao_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes_manutencao
    ADD CONSTRAINT solicitacoes_manutencao_pkey PRIMARY KEY (id);


--
-- Name: solicitacoes solicitacoes_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes
    ADD CONSTRAINT solicitacoes_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_armazenamentos_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_armazenamentos_id ON public.armazenamentos USING btree (id);


--
-- Name: ix_asset_categories_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_asset_categories_id ON public.asset_categories USING btree (id);


--
-- Name: ix_assets_e_patrimonio; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_assets_e_patrimonio ON public.assets USING btree (e_patrimonio);


--
-- Name: ix_assets_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_assets_id ON public.assets USING btree (id);


--
-- Name: ix_assets_nome; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_assets_nome ON public.assets USING btree (nome);


--
-- Name: ix_assets_numero_serie; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_assets_numero_serie ON public.assets USING btree (numero_serie);


--
-- Name: ix_assets_status; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_assets_status ON public.assets USING btree (status);


--
-- Name: ix_cost_centers_codigo; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_cost_centers_codigo ON public.cost_centers USING btree (codigo);


--
-- Name: ix_cost_centers_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_cost_centers_id ON public.cost_centers USING btree (id);


--
-- Name: ix_cost_centers_nome; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_cost_centers_nome ON public.cost_centers USING btree (nome);


--
-- Name: ix_departamentos_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_departamentos_id ON public.departamentos USING btree (id);


--
-- Name: ix_departamentos_nome; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_departamentos_nome ON public.departamentos USING btree (nome);


--
-- Name: ix_fornecedores_cnpj; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_fornecedores_cnpj ON public.fornecedores USING btree (cnpj);


--
-- Name: ix_fornecedores_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_fornecedores_id ON public.fornecedores USING btree (id);


--
-- Name: ix_fornecedores_nome; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_fornecedores_nome ON public.fornecedores USING btree (nome);


--
-- Name: ix_locais_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_locais_id ON public.locais USING btree (id);


--
-- Name: ix_maintenance_checklist_items_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_checklist_items_id ON public.maintenance_checklist_items USING btree (id);


--
-- Name: ix_maintenance_checklists_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_checklists_id ON public.maintenance_checklists USING btree (id);


--
-- Name: ix_maintenance_executions_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_executions_id ON public.maintenance_executions USING btree (id);


--
-- Name: ix_maintenance_history_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_history_id ON public.maintenance_history USING btree (id);


--
-- Name: ix_maintenance_materials_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_materials_id ON public.maintenance_materials USING btree (id);


--
-- Name: ix_maintenance_notifications_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_notifications_id ON public.maintenance_notifications USING btree (id);


--
-- Name: ix_maintenance_orders_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_orders_id ON public.maintenance_orders USING btree (id);


--
-- Name: ix_maintenance_orders_numero; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_maintenance_orders_numero ON public.maintenance_orders USING btree (numero);


--
-- Name: ix_maintenance_photos_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_photos_id ON public.maintenance_photos USING btree (id);


--
-- Name: ix_maintenance_plan_assets_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_plan_assets_id ON public.maintenance_plan_assets USING btree (id);


--
-- Name: ix_maintenance_plans_codigo; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_maintenance_plans_codigo ON public.maintenance_plans USING btree (codigo);


--
-- Name: ix_maintenance_plans_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_plans_id ON public.maintenance_plans USING btree (id);


--
-- Name: ix_maintenance_plans_nome; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_maintenance_plans_nome ON public.maintenance_plans USING btree (nome);


--
-- Name: ix_manutencoes_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_manutencoes_id ON public.manutencoes USING btree (id);


--
-- Name: ix_material_stock_transactions_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_material_stock_transactions_id ON public.material_stock_transactions USING btree (id);


--
-- Name: ix_material_stocks_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_material_stocks_id ON public.material_stocks USING btree (id);


--
-- Name: ix_movimentacoes_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_movimentacoes_id ON public.movimentacoes USING btree (id);


--
-- Name: ix_notas_fiscais_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_notas_fiscais_id ON public.notas_fiscais USING btree (id);


--
-- Name: ix_notas_fiscais_numero_nota; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_notas_fiscais_numero_nota ON public.notas_fiscais USING btree (numero_nota);


--
-- Name: ix_purchase_approvals_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_approvals_id ON public.purchase_approvals USING btree (id);


--
-- Name: ix_purchase_attachments_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_attachments_id ON public.purchase_attachments USING btree (id);


--
-- Name: ix_purchase_attachments_registro_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_attachments_registro_id ON public.purchase_attachments USING btree (registro_id);


--
-- Name: ix_purchase_attachments_tabela_origem; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_attachments_tabela_origem ON public.purchase_attachments USING btree (tabela_origem);


--
-- Name: ix_purchase_categories_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_categories_id ON public.purchase_categories USING btree (id);


--
-- Name: ix_purchase_categories_nome; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_purchase_categories_nome ON public.purchase_categories USING btree (nome);


--
-- Name: ix_purchase_contracts_data_fim; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_contracts_data_fim ON public.purchase_contracts USING btree (data_fim);


--
-- Name: ix_purchase_contracts_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_contracts_id ON public.purchase_contracts USING btree (id);


--
-- Name: ix_purchase_contracts_numero; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_purchase_contracts_numero ON public.purchase_contracts USING btree (numero);


--
-- Name: ix_purchase_history_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_history_id ON public.purchase_history USING btree (id);


--
-- Name: ix_purchase_history_registro_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_history_registro_id ON public.purchase_history USING btree (registro_id);


--
-- Name: ix_purchase_history_tabela_origem; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_history_tabela_origem ON public.purchase_history USING btree (tabela_origem);


--
-- Name: ix_purchase_notifications_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_notifications_id ON public.purchase_notifications USING btree (id);


--
-- Name: ix_purchase_order_items_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_order_items_id ON public.purchase_order_items USING btree (id);


--
-- Name: ix_purchase_orders_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_orders_id ON public.purchase_orders USING btree (id);


--
-- Name: ix_purchase_orders_numero; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_purchase_orders_numero ON public.purchase_orders USING btree (numero);


--
-- Name: ix_purchase_orders_status; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_orders_status ON public.purchase_orders USING btree (status);


--
-- Name: ix_purchase_products_codigo; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_purchase_products_codigo ON public.purchase_products USING btree (codigo);


--
-- Name: ix_purchase_products_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_products_id ON public.purchase_products USING btree (id);


--
-- Name: ix_purchase_products_nome; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_products_nome ON public.purchase_products USING btree (nome);


--
-- Name: ix_purchase_quotation_items_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_quotation_items_id ON public.purchase_quotation_items USING btree (id);


--
-- Name: ix_purchase_quotation_suppliers_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_quotation_suppliers_id ON public.purchase_quotation_suppliers USING btree (id);


--
-- Name: ix_purchase_quotations_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_quotations_id ON public.purchase_quotations USING btree (id);


--
-- Name: ix_purchase_quotations_numero; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_purchase_quotations_numero ON public.purchase_quotations USING btree (numero);


--
-- Name: ix_purchase_receiving_items_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_receiving_items_id ON public.purchase_receiving_items USING btree (id);


--
-- Name: ix_purchase_receivings_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_receivings_id ON public.purchase_receivings USING btree (id);


--
-- Name: ix_purchase_request_items_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_request_items_id ON public.purchase_request_items USING btree (id);


--
-- Name: ix_purchase_requests_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_requests_id ON public.purchase_requests USING btree (id);


--
-- Name: ix_purchase_requests_numero; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_purchase_requests_numero ON public.purchase_requests USING btree (numero);


--
-- Name: ix_purchase_requests_status; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_requests_status ON public.purchase_requests USING btree (status);


--
-- Name: ix_purchase_units_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_purchase_units_id ON public.purchase_units USING btree (id);


--
-- Name: ix_purchase_units_sigla; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_purchase_units_sigla ON public.purchase_units USING btree (sigla);


--
-- Name: ix_qr_logs_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_qr_logs_id ON public.qr_logs USING btree (id);


--
-- Name: ix_service_categories_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_service_categories_id ON public.service_categories USING btree (id);


--
-- Name: ix_service_definitions_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_service_definitions_id ON public.service_definitions USING btree (id);


--
-- Name: ix_service_ticket_interactions_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_service_ticket_interactions_id ON public.service_ticket_interactions USING btree (id);


--
-- Name: ix_service_tickets_codigo; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_service_tickets_codigo ON public.service_tickets USING btree (codigo);


--
-- Name: ix_service_tickets_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_service_tickets_id ON public.service_tickets USING btree (id);


--
-- Name: ix_solicitacoes_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_solicitacoes_id ON public.solicitacoes USING btree (id);


--
-- Name: ix_solicitacoes_manutencao_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_solicitacoes_manutencao_id ON public.solicitacoes_manutencao USING btree (id);


--
-- Name: ix_system_settings_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_system_settings_id ON public.system_settings USING btree (id);


--
-- Name: ix_system_settings_setting_key; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_system_settings_setting_key ON public.system_settings USING btree (setting_key);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_matricula; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_users_matricula ON public.users USING btree (matricula);


--
-- Name: ix_users_qr_token; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_users_qr_token ON public.users USING btree (qr_token);


--
-- Name: assets assets_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.asset_categories(id);


--
-- Name: assets assets_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: assets assets_current_armazenamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_current_armazenamento_id_fkey FOREIGN KEY (current_armazenamento_id) REFERENCES public.armazenamentos(id);


--
-- Name: assets assets_current_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_current_departamento_id_fkey FOREIGN KEY (current_departamento_id) REFERENCES public.departamentos(id);


--
-- Name: assets assets_current_local_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_current_local_id_fkey FOREIGN KEY (current_local_id) REFERENCES public.locais(id);


--
-- Name: assets assets_current_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_current_user_id_fkey FOREIGN KEY (current_user_id) REFERENCES public.users(id);


--
-- Name: assets assets_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_fornecedor_id_fkey FOREIGN KEY (fornecedor_id) REFERENCES public.fornecedores(id);


--
-- Name: assets assets_nota_fiscal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_nota_fiscal_id_fkey FOREIGN KEY (nota_fiscal_id) REFERENCES public.notas_fiscais(id);


--
-- Name: cost_centers cost_centers_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_departamento_id_fkey FOREIGN KEY (departamento_id) REFERENCES public.departamentos(id);


--
-- Name: cost_centers cost_centers_responsavel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_responsavel_id_fkey FOREIGN KEY (responsavel_id) REFERENCES public.users(id);


--
-- Name: departamentos departamentos_responsavel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.departamentos
    ADD CONSTRAINT departamentos_responsavel_id_fkey FOREIGN KEY (responsavel_id) REFERENCES public.users(id);


--
-- Name: locais locais_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.locais
    ADD CONSTRAINT locais_departamento_id_fkey FOREIGN KEY (departamento_id) REFERENCES public.departamentos(id);


--
-- Name: maintenance_checklist_items maintenance_checklist_items_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_checklist_items
    ADD CONSTRAINT maintenance_checklist_items_checklist_id_fkey FOREIGN KEY (checklist_id) REFERENCES public.maintenance_checklists(id);


--
-- Name: maintenance_checklists maintenance_checklists_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_checklists
    ADD CONSTRAINT maintenance_checklists_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.maintenance_plans(id);


--
-- Name: maintenance_executions maintenance_executions_checklist_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_executions
    ADD CONSTRAINT maintenance_executions_checklist_item_id_fkey FOREIGN KEY (checklist_item_id) REFERENCES public.maintenance_checklist_items(id);


--
-- Name: maintenance_executions maintenance_executions_executado_por_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_executions
    ADD CONSTRAINT maintenance_executions_executado_por_id_fkey FOREIGN KEY (executado_por_id) REFERENCES public.users(id);


--
-- Name: maintenance_executions maintenance_executions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_executions
    ADD CONSTRAINT maintenance_executions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.maintenance_orders(id);


--
-- Name: maintenance_history maintenance_history_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.maintenance_orders(id);


--
-- Name: maintenance_history maintenance_history_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.users(id);


--
-- Name: maintenance_materials maintenance_materials_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_materials
    ADD CONSTRAINT maintenance_materials_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.maintenance_orders(id);


--
-- Name: maintenance_notifications maintenance_notifications_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_notifications
    ADD CONSTRAINT maintenance_notifications_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.maintenance_orders(id);


--
-- Name: maintenance_notifications maintenance_notifications_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_notifications
    ADD CONSTRAINT maintenance_notifications_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.maintenance_plans(id);


--
-- Name: maintenance_notifications maintenance_notifications_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_notifications
    ADD CONSTRAINT maintenance_notifications_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.users(id);


--
-- Name: maintenance_orders maintenance_orders_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_orders
    ADD CONSTRAINT maintenance_orders_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: maintenance_orders maintenance_orders_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_orders
    ADD CONSTRAINT maintenance_orders_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.maintenance_plans(id);


--
-- Name: maintenance_orders maintenance_orders_service_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_orders
    ADD CONSTRAINT maintenance_orders_service_ticket_id_fkey FOREIGN KEY (service_ticket_id) REFERENCES public.service_tickets(id);


--
-- Name: maintenance_orders maintenance_orders_solicitante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_orders
    ADD CONSTRAINT maintenance_orders_solicitante_id_fkey FOREIGN KEY (solicitante_id) REFERENCES public.users(id);


--
-- Name: maintenance_orders maintenance_orders_tecnico_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_orders
    ADD CONSTRAINT maintenance_orders_tecnico_id_fkey FOREIGN KEY (tecnico_id) REFERENCES public.users(id);


--
-- Name: maintenance_photos maintenance_photos_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_photos
    ADD CONSTRAINT maintenance_photos_execution_id_fkey FOREIGN KEY (execution_id) REFERENCES public.maintenance_executions(id);


--
-- Name: maintenance_photos maintenance_photos_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_photos
    ADD CONSTRAINT maintenance_photos_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.maintenance_orders(id);


--
-- Name: maintenance_photos maintenance_photos_upload_por_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_photos
    ADD CONSTRAINT maintenance_photos_upload_por_id_fkey FOREIGN KEY (upload_por_id) REFERENCES public.users(id);


--
-- Name: maintenance_plan_assets maintenance_plan_assets_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plan_assets
    ADD CONSTRAINT maintenance_plan_assets_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: maintenance_plan_assets maintenance_plan_assets_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plan_assets
    ADD CONSTRAINT maintenance_plan_assets_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.maintenance_plans(id);


--
-- Name: maintenance_plans maintenance_plans_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plans
    ADD CONSTRAINT maintenance_plans_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.asset_categories(id);


--
-- Name: maintenance_plans maintenance_plans_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plans
    ADD CONSTRAINT maintenance_plans_departamento_id_fkey FOREIGN KEY (departamento_id) REFERENCES public.departamentos(id);


--
-- Name: maintenance_plans maintenance_plans_responsavel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.maintenance_plans
    ADD CONSTRAINT maintenance_plans_responsavel_id_fkey FOREIGN KEY (responsavel_id) REFERENCES public.users(id);


--
-- Name: manutencoes manutencoes_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.manutencoes
    ADD CONSTRAINT manutencoes_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: manutencoes manutencoes_destino_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.manutencoes
    ADD CONSTRAINT manutencoes_destino_user_id_fkey FOREIGN KEY (destino_user_id) REFERENCES public.users(id);


--
-- Name: manutencoes manutencoes_responsavel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.manutencoes
    ADD CONSTRAINT manutencoes_responsavel_id_fkey FOREIGN KEY (responsavel_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: material_stock_transactions material_stock_transactions_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.material_stock_transactions
    ADD CONSTRAINT material_stock_transactions_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.purchase_products(id);


--
-- Name: material_stock_transactions material_stock_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.material_stock_transactions
    ADD CONSTRAINT material_stock_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: material_stocks material_stocks_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.material_stocks
    ADD CONSTRAINT material_stocks_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.purchase_products(id);


--
-- Name: movimentacoes movimentacoes_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: movimentacoes movimentacoes_de_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_de_departamento_id_fkey FOREIGN KEY (de_departamento_id) REFERENCES public.departamentos(id);


--
-- Name: movimentacoes movimentacoes_de_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_de_user_id_fkey FOREIGN KEY (de_user_id) REFERENCES public.users(id);


--
-- Name: movimentacoes movimentacoes_para_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_para_departamento_id_fkey FOREIGN KEY (para_departamento_id) REFERENCES public.departamentos(id);


--
-- Name: movimentacoes movimentacoes_para_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.movimentacoes
    ADD CONSTRAINT movimentacoes_para_user_id_fkey FOREIGN KEY (para_user_id) REFERENCES public.users(id);


--
-- Name: notas_fiscais notas_fiscais_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.notas_fiscais
    ADD CONSTRAINT notas_fiscais_fornecedor_id_fkey FOREIGN KEY (fornecedor_id) REFERENCES public.fornecedores(id);


--
-- Name: purchase_approvals purchase_approvals_aprovador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_approvals
    ADD CONSTRAINT purchase_approvals_aprovador_id_fkey FOREIGN KEY (aprovador_id) REFERENCES public.users(id);


--
-- Name: purchase_approvals purchase_approvals_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_approvals
    ADD CONSTRAINT purchase_approvals_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.purchase_requests(id);


--
-- Name: purchase_contracts purchase_contracts_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_contracts
    ADD CONSTRAINT purchase_contracts_fornecedor_id_fkey FOREIGN KEY (fornecedor_id) REFERENCES public.fornecedores(id);


--
-- Name: purchase_history purchase_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_history
    ADD CONSTRAINT purchase_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: purchase_notifications purchase_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_notifications
    ADD CONSTRAINT purchase_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: purchase_order_items purchase_order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.purchase_orders(id);


--
-- Name: purchase_order_items purchase_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.purchase_products(id);


--
-- Name: purchase_orders purchase_orders_centro_custo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_centro_custo_id_fkey FOREIGN KEY (centro_custo_id) REFERENCES public.cost_centers(id);


--
-- Name: purchase_orders purchase_orders_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_fornecedor_id_fkey FOREIGN KEY (fornecedor_id) REFERENCES public.fornecedores(id);


--
-- Name: purchase_orders purchase_orders_quotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_quotation_id_fkey FOREIGN KEY (quotation_id) REFERENCES public.purchase_quotations(id);


--
-- Name: purchase_orders purchase_orders_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.purchase_requests(id);


--
-- Name: purchase_products purchase_products_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_products
    ADD CONSTRAINT purchase_products_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.purchase_categories(id);


--
-- Name: purchase_quotation_items purchase_quotation_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotation_items
    ADD CONSTRAINT purchase_quotation_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.purchase_products(id);


--
-- Name: purchase_quotation_items purchase_quotation_items_quotation_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotation_items
    ADD CONSTRAINT purchase_quotation_items_quotation_supplier_id_fkey FOREIGN KEY (quotation_supplier_id) REFERENCES public.purchase_quotation_suppliers(id);


--
-- Name: purchase_quotation_suppliers purchase_quotation_suppliers_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotation_suppliers
    ADD CONSTRAINT purchase_quotation_suppliers_fornecedor_id_fkey FOREIGN KEY (fornecedor_id) REFERENCES public.fornecedores(id);


--
-- Name: purchase_quotation_suppliers purchase_quotation_suppliers_quotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotation_suppliers
    ADD CONSTRAINT purchase_quotation_suppliers_quotation_id_fkey FOREIGN KEY (quotation_id) REFERENCES public.purchase_quotations(id);


--
-- Name: purchase_quotations purchase_quotations_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_quotations
    ADD CONSTRAINT purchase_quotations_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.purchase_requests(id);


--
-- Name: purchase_receiving_items purchase_receiving_items_ativo_criado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receiving_items
    ADD CONSTRAINT purchase_receiving_items_ativo_criado_id_fkey FOREIGN KEY (ativo_criado_id) REFERENCES public.assets(id);


--
-- Name: purchase_receiving_items purchase_receiving_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receiving_items
    ADD CONSTRAINT purchase_receiving_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.purchase_products(id);


--
-- Name: purchase_receiving_items purchase_receiving_items_receiving_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receiving_items
    ADD CONSTRAINT purchase_receiving_items_receiving_id_fkey FOREIGN KEY (receiving_id) REFERENCES public.purchase_receivings(id);


--
-- Name: purchase_receivings purchase_receivings_nota_fiscal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receivings
    ADD CONSTRAINT purchase_receivings_nota_fiscal_id_fkey FOREIGN KEY (nota_fiscal_id) REFERENCES public.notas_fiscais(id);


--
-- Name: purchase_receivings purchase_receivings_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receivings
    ADD CONSTRAINT purchase_receivings_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.purchase_orders(id);


--
-- Name: purchase_receivings purchase_receivings_responsavel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_receivings
    ADD CONSTRAINT purchase_receivings_responsavel_id_fkey FOREIGN KEY (responsavel_id) REFERENCES public.users(id);


--
-- Name: purchase_request_items purchase_request_items_fornecedor_sugerido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_fornecedor_sugerido_id_fkey FOREIGN KEY (fornecedor_sugerido_id) REFERENCES public.fornecedores(id);


--
-- Name: purchase_request_items purchase_request_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.purchase_products(id);


--
-- Name: purchase_request_items purchase_request_items_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.purchase_requests(id);


--
-- Name: purchase_requests purchase_requests_centro_custo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_centro_custo_id_fkey FOREIGN KEY (centro_custo_id) REFERENCES public.cost_centers(id);


--
-- Name: purchase_requests purchase_requests_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_departamento_id_fkey FOREIGN KEY (departamento_id) REFERENCES public.departamentos(id);


--
-- Name: purchase_requests purchase_requests_origem_os_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_origem_os_id_fkey FOREIGN KEY (origem_os_id) REFERENCES public.maintenance_orders(id);


--
-- Name: purchase_requests purchase_requests_origem_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_origem_ticket_id_fkey FOREIGN KEY (origem_ticket_id) REFERENCES public.service_tickets(id);


--
-- Name: purchase_requests purchase_requests_solicitante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_solicitante_id_fkey FOREIGN KEY (solicitante_id) REFERENCES public.users(id);


--
-- Name: qr_logs qr_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.qr_logs
    ADD CONSTRAINT qr_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: qr_logs qr_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.qr_logs
    ADD CONSTRAINT qr_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: service_definitions service_definitions_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_definitions
    ADD CONSTRAINT service_definitions_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.service_categories(id);


--
-- Name: service_ticket_interactions service_ticket_interactions_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_ticket_interactions
    ADD CONSTRAINT service_ticket_interactions_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.service_tickets(id);


--
-- Name: service_ticket_interactions service_ticket_interactions_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_ticket_interactions
    ADD CONSTRAINT service_ticket_interactions_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.users(id);


--
-- Name: service_tickets service_tickets_servico_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_servico_id_fkey FOREIGN KEY (servico_id) REFERENCES public.service_definitions(id);


--
-- Name: service_tickets service_tickets_solicitante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_solicitante_id_fkey FOREIGN KEY (solicitante_id) REFERENCES public.users(id);


--
-- Name: service_tickets service_tickets_tecnico_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.service_tickets
    ADD CONSTRAINT service_tickets_tecnico_id_fkey FOREIGN KEY (tecnico_id) REFERENCES public.users(id);


--
-- Name: solicitacoes solicitacoes_aprovador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes
    ADD CONSTRAINT solicitacoes_aprovador_id_fkey FOREIGN KEY (aprovador_id) REFERENCES public.users(id);


--
-- Name: solicitacoes solicitacoes_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes
    ADD CONSTRAINT solicitacoes_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: solicitacoes solicitacoes_confirmado_por_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes
    ADD CONSTRAINT solicitacoes_confirmado_por_id_fkey FOREIGN KEY (confirmado_por_id) REFERENCES public.users(id);


--
-- Name: solicitacoes_manutencao solicitacoes_manutencao_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes_manutencao
    ADD CONSTRAINT solicitacoes_manutencao_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id);


--
-- Name: solicitacoes_manutencao solicitacoes_manutencao_manutencao_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes_manutencao
    ADD CONSTRAINT solicitacoes_manutencao_manutencao_id_fkey FOREIGN KEY (manutencao_id) REFERENCES public.manutencoes(id);


--
-- Name: solicitacoes_manutencao solicitacoes_manutencao_responsavel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes_manutencao
    ADD CONSTRAINT solicitacoes_manutencao_responsavel_id_fkey FOREIGN KEY (responsavel_id) REFERENCES public.users(id);


--
-- Name: solicitacoes_manutencao solicitacoes_manutencao_solicitante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes_manutencao
    ADD CONSTRAINT solicitacoes_manutencao_solicitante_id_fkey FOREIGN KEY (solicitante_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: solicitacoes solicitacoes_solicitante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.solicitacoes
    ADD CONSTRAINT solicitacoes_solicitante_id_fkey FOREIGN KEY (solicitante_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_departamento_id_fkey FOREIGN KEY (departamento_id) REFERENCES public.departamentos(id);


--
-- PostgreSQL database dump complete
--

\unrestrict QhvD2eGrad2IaxBamhzBZtFbpENclcldia5p8gikeYIYmNfYGIcXyd4x6HVporb

